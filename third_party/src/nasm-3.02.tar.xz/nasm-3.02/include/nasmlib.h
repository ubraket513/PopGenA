/* SPDX-License-Identifier: BSD-2-Clause */
/* Copyright 1996-2025 The NASM Authors - All Rights Reserved */

/*
 * nasmlib.h    header file for nasmlib.c
 */

#ifndef NASM_NASMLIB_H
#define NASM_NASMLIB_H

#include "compiler.h"
#include "bytesex.h"

/*
 * Useful construct for private values
 */
union intorptr {
    int64_t i;
    uint64_t u;
    size_t s;
    void *p;
    const void *cp;
    uintptr_t up;
};
typedef union intorptr intorptr;

/*
 * Handy macro to use as the base of shifts
 */
#define ONE ((uintmax_t)1)

/*
 * Handy macros for defining and accessing enums of bitfields;
 * provides a set of standard-named parameters for each field.
 *
 * mk_field_mask() is indended to be used for non-contiguous fields.
 */

#define mk_field_mask(name,pos,width,basemask)              \
    name ## _POS = (pos),                                   \
    name ## _WIDTH = (width),                               \
    name ## _BASEMASK = (basemask),                         \
    name ## _MASK = name ## _BASEMASK << name ## _POS,      \
    name = name ## _MASK

#define mk_field(name,pos,width)                            \
    mk_field_mask(name,pos,width,                           \
                  (1 << name ## _WIDTH)-1)

/*
 * Cast a value to a suitable type to represent the encoded
 * (post-shift) and extracted (pre-shift) values, respectively.
 */
#ifdef HAVE_TYPEOF
# define fieldenc_cast(x,y) ((typeof(x ## _MASK))(y))
# define fieldval_cast(x,y) ((typeof(x ## _BASEMASK))(y))
#else
/*
 * Using int here matches the strict ISO C before C23 which only allows
 * an enum to be in the range of "int". This also means that these macros
 * are only usable for bitfields up to 32 bits wide, which is extremely
 * unfortunate, but covers most of all the NASM use cases.
 *
 * The (int) should at least give a warning on overflow.
 */
# define fieldenc_cast(x,y) ((int)(y))
# define fieldval_cast(x,y) (y)
#endif

/*
 * Macros to get/set bitfield values (the set macro returns the
 * updated value, it does not change the input.)
 *
 * The fieldenc() macro produces the masked and shifted value
 * corresponding to a base value; it is equivalent to
 * setfield(field,0,val).
 */
#define getfield(field,from)                            \
    fieldval_cast(field,                                \
                  (((from) >> field ## _POS) &          \
                   field ## _BASEMASK))
#define fieldval(field,val)                                \
    (((val) & fieldenc_cast(field,field ## _BASEMASK))     \
     << field ## _POS)
#define setfield(field,from,val)                        \
    (((from) & ~(field ## _MASK)) + fieldval(field,val))

/*
 * Wrappers around malloc, realloc, free and a few more. nasm_malloc
 * will fatal-error and die rather than return NULL; nasm_realloc will
 * do likewise, and will also guarantee to work right on being passed
 * a NULL pointer; nasm_free will do nothing if it is passed a NULL
 * pointer.
 */
void * safe_malloc(1) nasm_malloc(size_t);
void * safe_malloc(1) nasm_zalloc(size_t);
void * safe_malloc2(1,2) nasm_calloc(size_t, size_t);
void * safe_realloc(2) nasm_realloc(void *, size_t);
void nasm_free(void *);
char * safe_alloc nasm_strdup(const char *);
char * safe_alloc nasm_strndup(const char *, size_t);
char * safe_alloc nasm_strcat(const char *one, const char *two);
char * safe_alloc end_with_null nasm_strcatn(const char *one, ...);

/*
 * Replace a string in a string pointer variable with a nasm_strdup()
 * copy of the argument on the right, freeing the contents of the
 * previous contents of the variable if non-NULL.
 *
 * If *str is NULL, simply return the old value of *ptrp.
 */
char *nasm_strdupto(char **ptrp, const char *str);

/*
 * Similar, but the new pointer must already have been heap allocated
 * by the creating function.
 */
static inline char *nasm_strto(char **ptrp, char *str)
{
    char *ptr = *ptrp;
    if (!str)
        return ptr;
    if (ptr)
        nasm_free(ptr);
    return *ptrp = str;
}

/*
 * nasm_[v]asprintf() are variants of the semi-standard [v]asprintf()
 * functions, except that we return the pointer instead of a count.
 * The size of the string (including the final NUL!) is available
 * by calling nasm_last_string_size() afterwards.
 *
 * nasm_[v]axprintf() are similar, but allocates a user-defined amount
 * of storage before the string, and returns a pointer to the
 * allocated buffer. The value of nasm_last_string_size() does *not* include
 * this additional storage.
 */
char * safe_alloc printf_func(1, 2) nasm_asprintf(const char *fmt, ...);
char * safe_alloc vprintf_func(1) nasm_vasprintf(const char *fmt, va_list ap);
void * safe_alloc printf_func(2, 3) nasm_axprintf(size_t extra, const char *fmt, ...);
void * safe_alloc vprintf_func(2) nasm_vaxprintf(size_t extra, const char *fmt, va_list ap);

/*
 * nasm_last_string_len() returns the length of the last string allocated
 * by [v]asprintf, nasm_strdup, nasm_strcat, or nasm_strcatn.
 *
 * nasm_last_string_size() returns the equivalent size including the
 * final NUL.
 */
static inline size_t nasm_last_string_len(void)
{
    extern size_t _nasm_last_string_size;
    return _nasm_last_string_size - 1;
}
static inline size_t nasm_last_string_size(void)
{
    extern size_t _nasm_last_string_size;
    return _nasm_last_string_size;
}

/*
 * All zero data buffer
 */
#define ZERO_BUF_SIZE 65536     /* Default value */
#if defined(BUFSIZ) && (BUFSIZ > ZERO_BUF_SIZE)
# undef ZERO_BUF_SIZE
# define ZERO_BUF_SIZE BUFSIZ
#endif
extern const uint8_t zero_buffer[ZERO_BUF_SIZE];

/*
 * Statically assert the argument is a pointer without evaluating it.
 * ? : requires that the types on both sides are compatible, and
 * const volatile void * is compatible with any pointer type.
 * Avoid a simple cast from NULL because it might make some compilers
 * confused; a pointer to any object works there.
 */
#define nasm_assert_pointer(p) \
    ((void)sizeof(1 ? (p) : (const volatile void *)&zero_buffer))

#define nasm_new(p) ((p) = nasm_zalloc(sizeof(*(p))))
#define nasm_newn(p,n) ((p) = nasm_calloc((n), sizeof(*(p))))
/*
 * This is broken on platforms where there are pointers which don't
 * match void * in their internal layout.  It unfortunately also
 * loses any "const" part of the argument, although hopefully the
 * compiler will warn in that case.
 */
#define nasm_delete(p)                          \
    do {                                        \
        void **_pp = (void **)&(p);             \
        nasm_assert_pointer(p);                 \
        nasm_free(*_pp);                        \
        *_pp = NULL;                            \
    } while (0)
#define nasm_zero(x) (memset(&(x), 0, sizeof(x)))
#define nasm_zeron(p,n) (memset((p), 0, (n)*sizeof(*(p))))

/*
 * Wrappers around fread()/fwrite() which fatal-errors on failure.
 * For fread(), only use this if EOF is supposed to be a fatal error!
 */
void nasm_read(void *, size_t, FILE *);
void nasm_write(const void *, size_t, FILE *);

/*
 * NASM failure at build time if the argument is false
 */
#ifdef static_assert
# define nasm_static_assert(x) static_assert((x), #x)
#elif defined(HAVE_FUNC_ATTRIBUTE_ERROR) && defined(__OPTIMIZE__)
# define nasm_static_assert(x)                                              \
    do {                                                                    \
        if (!(x)) {                                                         \
            extern void __attribute__((error("assertion " #x " failed")))   \
                _nasm_static_fail(void);                                    \
            _nasm_static_fail();                                            \
        }                                                                   \
    } while (0)
#else
/* See http://www.drdobbs.com/compile-time-assertions/184401873 */
# define nasm_static_assert(x)                                              \
    do { enum { _static_assert_failed = 1/(!!(x)) }; } while (0)
#endif

/*
 * conditional static assert, if we know it is possible to determine
 * the assert value at compile time. Since if_constant triggers
 * pedantic warnings on gcc, turn them off explicitly around this code.
 */
#ifdef static_assert
# define nasm_try_static_assert(x)                                          \
    do {                                                                    \
        not_pedantic_start                                                  \
        static_assert(if_constant(x, true), #x);                            \
        not_pedantic_end                                                    \
    } while (0)
#elif defined(HAVE_FUNC_ATTRIBUTE_ERROR) && defined(__OPTIMIZE__)
# define nasm_try_static_assert(x)                                          \
    do {                                                                    \
        if (!if_constant(x, true)) {                                        \
            extern void __attribute__((error("assertion " #x " failed")))   \
                _nasm_static_fail(void);                                    \
            _nasm_static_fail();                                            \
        }                                                                   \
    } while (0)
#else
# define nasm_try_static_assert(x) ((void)0)
#endif

/*
 * NASM assert failure
 */
fatal_func nasm_assert_failed(const char *msg, const char *func,
                              const char *file, int line);

/* Plain assert, gives the source location as an error message */
#define nasm_assert(x)                                                  \
    do {                                                                \
        nasm_try_static_assert(x);                                      \
        if (unlikely(!(x)))                                             \
            nasm_assert_failed(#x,NASM_FUNC,__FILE__,__LINE__);         \
    } while (0)

/* Assert with custom message */
#define nasm_assert_msg(x,m)                    \
    do {                                        \
        nasm_try_static_assert(x);              \
        if (unlikely(!(x)))                     \
            nasm_panic("%s", m);                \
    } while (0)

/* Utility function to generate a string for an invalid enum */
const char *invalid_enum_str(int);

/*
 * ANSI doesn't guarantee the presence of `stricmp' or
 * `strcasecmp'.
 */
#if defined(HAVE_STRCASECMP)
#define nasm_stricmp strcasecmp
#elif defined(HAVE_STRICMP)
#define nasm_stricmp stricmp
#else
int pure_func nasm_stricmp(const char *, const char *);
#endif

#if defined(HAVE_STRNCASECMP)
#define nasm_strnicmp strncasecmp
#elif defined(HAVE_STRNICMP)
#define nasm_strnicmp strnicmp
#else
int pure_func nasm_strnicmp(const char *, const char *, size_t);
#endif

int pure_func nasm_memicmp(const char *, const char *, size_t);

#if defined(HAVE_STRSEP)
#define nasm_strsep strsep
#else
char *nasm_strsep(char **stringp, const char *delim);
#endif

#ifndef HAVE_DECL_STRNLEN
size_t pure_func strnlen(const char *, size_t);
#endif

/* This returns the numeric value of a given 'digit'; no check for validity */
static inline unsigned int numvalue(unsigned char c)
{
    c |= 0x20;
    return c >= 'a' ? c - 'a' + 10 : c - '0';
}

/* The same except returns -1U for non-digits, so it can be directly
 * compared against the base used to test for validity. */
static inline unsigned int numvalue_chk(unsigned char c)
{
    unsigned int v;
    v = c - '0';
    if (v < 10)
        return v;

    v = (c | 0x20) - 'a';
    if (v < 26)
        return v + 10;

    return -1U;
}

/*
 * Convert a string into a number, using NASM number rules. Sets
 * `*error' to true if an error occurs, and false otherwise.
 */
int64_t readnum(const char *str, bool *error);

/*
 * Warn for the use of $ as a hexadecimal prefix
 */
void warn_dollar_hex(void);

/*
 * Get the numeric base corresponding to a character
 */
static inline unsigned int radix_letter(char c)
{
    switch (c) {
    case 'b': case 'B':
    case 'y': case 'Y':
	return 2;		/* Binary */
    case 'o': case 'O':
    case 'q': case 'Q':
	return 8;		/* Octal */
    case 'h': case 'H':
    case 'x': case 'X':
	return 16;		/* Hexadecimal */
    case 'd': case 'D':
    case 't': case 'T':
	return 10;		/* Decimal */
    default:
	return 0;		/* Not a known radix letter */
    }
}

/*
 * Convert a character constant into a number. Sets
 * `*warn' to true if an overflow occurs, and false otherwise.
 * str points to and length covers the middle of the string,
 * without the quotes.
 */
int64_t readstrnum(char *str, int length, bool *warn);

/*
 * Produce an unsigned integer string from a number with a specified
 * base, digits and signedness
 */
#define NUMSTR_MAXBASE 64
int numstr(char *buf, size_t buflen, uint64_t n,
           int digits, unsigned int base, bool ucase);

extern const char * const nasmlib_digit_chars[2];
static inline const char *nasm_digit_chars(bool ucase)
{
    return nasmlib_digit_chars[ucase];
}

/*
 * seg_alloc: allocate a hitherto unused segment number.
 */
int32_t seg_alloc(void);

/*
 * Add/replace or remove an extension to the end of a filename;
 * returns a newly allocated buffer with the modified filename.
 */
char *filename_set_extension(const char *inname, const char *extension);

/*
 * Utility macros...
 *
 * This is a useful #define which I keep meaning to use more often:
 * the number of elements of a statically defined array.
 */
#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))
#define ARRAY_END(arr)  (&(arr)[ARRAY_SIZE(arr)])
#define array_for_each(var,arr) \
    for ((var) = (arr); (var) < ARRAY_END(arr); (var)++)


/*
 * List handling
 *
 *  list_for_each - regular iterator over list
 *  list_for_each_safe - the same but safe against list items removal
 *  list_last - find the last element in a list
 *  list_reverse - reverse the order of a list
 *
 *  Arguments named with _ + single letter should be temp variables
 *  of the appropriate pointer type.
 */
#define list_for_each(pos, head)                        \
    for (pos = head; pos; pos = pos->next)
#define list_for_each_safe(pos, _n, head)                \
    for (pos = head, _n = (pos ? pos->next : NULL); pos; \
        pos = _n, _n = (_n ? _n->next : NULL))
#define list_last(pos, head)                                    \
    do {                                                        \
        for (pos = head; pos && pos->next; pos = pos->next)     \
            ;                                                   \
    } while (0)
#define list_reverse(head)                              \
    do {                                                \
        void *_p, *_n;                                  \
        if (!head || !head->next)                       \
            break;                                      \
        _p = NULL;                                      \
        while (head) {                                  \
            _n = head->next;                            \
            head->next = _p;                            \
            _p = head;                                  \
            head = _n;                                  \
        }                                               \
        head = _p;                                      \
    } while (0)

/*
 * Power of 2 align helpers
 */
#undef ALIGN_MASK               /* Some BSD flavors define these in system headers */
#undef ALIGN
#define ALIGN_MASK(v, mask)     (((v) + (mask)) & ~(mask))
#define ALIGN(v, a)             ALIGN_MASK(v, (a) - 1)
#define IS_ALIGNED(v, a)        (((v) & ((a) - 1)) == 0)

/*
 * Routines to write littleendian data to a file
 */
#define fwriteint8_t(d,f) putc(d,f)
void fwriteint16_t(uint16_t data, FILE * fp);
void fwriteint32_t(uint32_t data, FILE * fp);
void fwriteint64_t(uint64_t data, FILE * fp);
void fwriteaddr(uint64_t data, int size, FILE * fp);

/*
 * Binary search routine. Returns index into `array' of an entry
 * matching `string', or <0 if no match. `array' is taken to
 * contain `size' elements.
 *
 * bsi() is case sensitive, bsii() is case insensitive.
 */
int pure_func bsi(const char *string, const char **array, int size);
int pure_func bsii(const char *string, const char **array, int size);

/*
 * Convenient string processing helper routines
 */
char * pure_func nasm_skip_spaces(const char *p);
char * pure_func nasm_skip_word(const char *p);
char *nasm_zap_spaces_fwd(char *p);
char *nasm_zap_spaces_rev(char *p);
char *nasm_trim_spaces(char *p);
char *nasm_get_word(char *p, char **tail);
char *nasm_opt_val(char *p, char **opt, char **val);

/*
 * Converts a relative pathname rel_path into an absolute path name.
 *
 * The buffer returned must be freed by the caller
 */
char * safe_alloc nasm_realpath(const char *rel_path);

/*
 * Path-splitting and merging functions
 */
char * safe_alloc nasm_dirname(const char *path);
char * safe_alloc nasm_basename(const char *path);
char * safe_alloc nasm_catfile(const char *dir, const char *path);

/*
 * Various tokens to readable strings, with limit checking
 */
const char * const_func register_name(int);
const char * const_func prefix_name(int);
bool const_func is_hint_nop(uint64_t);

/*
 * Wrappers around fopen()... for future change to a dedicated structure
 */
enum file_flags {
    NF_BINARY   = 0x00000000,   /* Binary file (default) */
    NF_TEXT     = 0x00000001,   /* Text file */
    NF_NONFATAL = 0x00000000,   /* Don't die on open failure (default) */
    NF_FATAL    = 0x00000002,   /* Die on open failure */
    NF_FORMAP   = 0x00000004,   /* Intended to use nasm_map_file() */
    NF_IONBF    = 0x00000010,   /* Force unbuffered stdio */
    NF_IOLBF    = 0x00000020,   /* Force line buffered stdio */
    NF_IOFBF    = 0000000030    /* Force fully buffered stdio */
};
#define NF_BUF_MASK  0x30

FILE *nasm_open_read(const char *filename, enum file_flags flags);
FILE *nasm_open_write(const char *filename, enum file_flags flags);

void nasm_set_binary_mode(FILE *f);

/* Probe for existence of a file */
bool nasm_file_exists(const char *filename);

/* Missing fseeko/ftello */
#ifndef HAVE_FSEEKO
# undef off_t                   /* Just in case it is a macro */
# ifdef HAVE__FSEEKI64
#  define fseeko _fseeki64
#  define ftello _ftelli64
#  define off_t  int64_t
# else
#  define fseeko fseek
#  define ftello ftell
#  define off_t  long
# endif
#endif

const void *nasm_map_file(FILE *fp, off_t start, off_t len);
void nasm_unmap_file(const void *p, size_t len);
off_t nasm_file_size(FILE *f);
off_t nasm_file_size_by_path(const char *pathname);
bool nasm_file_time(time_t *t, const char *pathname);
void fwritezero(off_t bytes, FILE *fp);

/* Sign-extend a value to an arbitrary number of bits */
static inline int64_t const_func sext(int64_t value, unsigned int bits)
{
    if (is_constant(bits)) {
        switch (bits) {
        case 8:
            return (int8_t)value;
        case 16:
            return (int16_t)value;
        case 32:
            return (int32_t)value;
        default:
            break;
        }
    }

    if (bits >= 64)
        return value;

    /* sext(foo,0) == sext(foo,1) */
    bits = bits ? 64-bits : 63;

    return value << bits >> bits;
}

/* Zero-extend a value to an arbitrary number of bits */
static inline uint64_t const_func zext(uint64_t value, unsigned int bits)
{
    if (is_constant(bits)) {
        switch (bits) {
        case 8:
            return (uint8_t)value;
        case 16:
            return (uint16_t)value;
        case 32:
            return (uint32_t)value;
        default:
            break;
        }
    }

    if (bits >= 64)
        return value;

    if (!bits)
        return 0;

    bits = 64-bits;
    return value << bits >> bits;
}

static inline bool const_func overflow_signed(int64_t value, unsigned int bytes)
{
    return sext(value, bytes << 3) != value;
}

static inline bool const_func overflow_unsigned(uint64_t value, unsigned int bytes)
{
    return zext(value, bytes << 3) != value;
}

/* This is very conservative, but otherwise things like ~0x80 break */
static inline bool const_func overflow_general(int64_t value, unsigned int bytes)
{
    return overflow_unsigned(value, bytes) && overflow_unsigned(-value, bytes);
}

/* check if value is power of 2 */
#define is_power2(v)   ((v) && ((v) & ((v) - 1)) == 0)

/* try to get the system stack size */
extern size_t nasm_get_stack_size_limit(void);

#endif
